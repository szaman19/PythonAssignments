import libraryGuiGrid

def main():
    gui = libraryGuiGrid.LibraryGridGUI()
main()
